package invite

import "github.com/google/uuid"

type InviteService struct {
	store    *InviteStore
	auditLog *AuditLog
}

func NewInviteService(store *InviteStore, auditLog *AuditLog) *InviteService {
	return &InviteService{store: store, auditLog: auditLog}
}

func (s *InviteService) CreateInvite(assessmentID, candidateEmail string, expiresAt int64) *Invite {
	for _, inv := range s.store.All() {
		if inv.AssessmentID == assessmentID && inv.CandidateEmail == candidateEmail &&
			(inv.Status == "PENDING" || inv.Status == "SENT") {
			return nil
		}
	}
	inv := &Invite{InviteID: uuid.NewString(), AssessmentID: assessmentID, CandidateEmail: candidateEmail, Status: "PENDING", ExpiresAt: expiresAt}
	s.store.Save(inv)
	return inv
}

func (s *InviteService) SendInvite(inviteID string, now int64) string {
	inv := s.store.Get(inviteID)
	if inv == nil {
		return "NOT_FOUND"
	}
	if inv.Status == "SENT" {
		return "ALREADY_SENT"
	}
	if inv.Status == "EXPIRED" {
		return "ALREADY_EXPIRED"
	}
	if inv.Status != "PENDING" {
		return "NOT_FOUND"
	}

	oldStatus := inv.Status
	if inv.ExpiresAt <= now {
		inv.Status = "EXPIRED"
		s.store.Save(inv)
		s.auditLog.LogChange(inv.InviteID, oldStatus, "EXPIRED", now)
		return "EXPIRED"
	}
	inv.Status = "SENT"
	inv.SentAt = &now
	s.store.Save(inv)
	s.auditLog.LogChange(inv.InviteID, oldStatus, "SENT", now)
	return "SENT"
}

func (s *InviteService) Resend(inviteID string, newExpiresAt, now int64) string {
	inv := s.store.Get(inviteID)
	if inv == nil {
		return "NOT_FOUND"
	}
	if inv.Status != "EXPIRED" {
		return "CANNOT_RESEND"
	}

	oldStatus := inv.Status
	inv.Status = "PENDING"
	inv.ExpiresAt = newExpiresAt
	inv.SentAt = nil
	s.store.Save(inv)
	s.auditLog.LogChange(inv.InviteID, oldStatus, "PENDING", now)
	return "RESENT"
}
