package invite

type AuditLog struct{ Changes []StatusChange }

func NewAuditLog() *AuditLog { return &AuditLog{} }

func (a *AuditLog) LogChange(inviteID, oldStatus, newStatus string, timestamp int64) {
	a.Changes = append(a.Changes, StatusChange{InviteID: inviteID, OldStatus: oldStatus, NewStatus: newStatus, Timestamp: timestamp})
}

func (a *AuditLog) GetStats(assessmentID string, store *InviteStore) map[string]int {
	stats := make(map[string]int)
	for _, inv := range store.All() {
		if inv.AssessmentID == assessmentID {
			stats[inv.Status]++
		}
	}
	return stats
}
