package invite

type BulkProcessor struct{ service *InviteService }

func NewBulkProcessor(service *InviteService) *BulkProcessor { return &BulkProcessor{service: service} }

func (b *BulkProcessor) BulkSend(assessmentID string, emails []string, expiresAt, now int64) BulkSendResult {
	result := BulkSendResult{}
	seen := make(map[string]bool)
	for _, email := range emails {
		if seen[email] {
			result.Skipped = append(result.Skipped, email)
			continue
		}
		seen[email] = true
		inv := b.service.CreateInvite(assessmentID, email, expiresAt)
		if inv == nil {
			result.Skipped = append(result.Skipped, email)
			continue
		}
		if b.service.SendInvite(inv.InviteID, now) == "SENT" {
			result.Sent = append(result.Sent, inv.InviteID)
		} else {
			result.Failed = append(result.Failed, inv.InviteID)
		}
	}
	return result
}
