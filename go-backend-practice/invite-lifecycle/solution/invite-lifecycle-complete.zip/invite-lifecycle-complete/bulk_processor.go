package invite

type BulkProcessor struct {
	service *InviteService
}

func NewBulkProcessor(service *InviteService) *BulkProcessor {
	return &BulkProcessor{service: service}
}

// BulkSend creates and sends invites for a list of emails.
//
// For each email:
//   - Call CreateInvite.
//   - If nil (conflict/duplicate), append the email to Skipped.
//   - Otherwise call SendInvite on the new invite.
//   - If "SENT", append invite ID to Sent.
//   - If "EXPIRED", append invite ID to Failed.
//
// Process each email only once; duplicate emails in the input are Skipped.
//
// Return a BulkSendResult with Sent, Skipped, and Failed slices.
func (b *BulkProcessor) BulkSend(assessmentID string, emails []string, expiresAt, now int64) BulkSendResult {
	result := BulkSendResult{}
	seen := make(map[string]bool)

	for _, email := range emails {
		if seen[email] {
			result.Skipped = append(result.Skipped, email)
			continue
		}
		seen[email] = true

		inv := b.service.CreateInvite(assessmentID, email, expiresAt)
		if inv == nil {
			result.Skipped = append(result.Skipped, email)
			continue
		}

		status := b.service.SendInvite(inv.InviteID, now)
		switch status {
		case "SENT":
			result.Sent = append(result.Sent, inv.InviteID)
		case "EXPIRED":
			result.Failed = append(result.Failed, inv.InviteID)
		default:
			result.Failed = append(result.Failed, inv.InviteID)
		}
	}

	return result
}
